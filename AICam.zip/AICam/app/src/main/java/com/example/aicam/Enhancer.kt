package com.example.aicam

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/** On-device auto enhancement: auto-levels, adaptive gamma, saturation, sharpening. */
object Enhancer {

    fun enhanceAndSave(ctx: Context, uri: Uri, name: String): Uri? = try {
        val src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, _, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            d.isMutableRequired = true
        }
        val out = enhance(src)
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "${name}_AI")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AICam")
        }
        val newUri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        newUri?.also { u -> ctx.contentResolver.openOutputStream(u)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) } }
    } catch (e: Exception) { null }

    private fun luma(p: Int) = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8

    fun enhance(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height; val n = w * h
        val px = IntArray(n); src.getPixels(px, 0, w, 0, 0, w, h)

        // 1) Auto levels (clip 0.5% at both ends)
        val hist = IntArray(256); for (p in px) hist[luma(p)]++
        fun pct(f: Float): Int { var s = 0; val t = n * f; for (i in 0..255) { s += hist[i]; if (s >= t) return i }; return 255 }
        val lo = pct(0.005f); val hi = pct(0.995f).coerceAtLeast(lo + 1)
        fun lvl(i: Int) = ((i - lo).toFloat() / (hi - lo)).coerceIn(0f, 1f)

        // 2) Adaptive gamma: lift dark scenes toward mid-tone target, gently
        var mean = 0.0; for (i in 0..255) mean += hist[i] * lvl(i).toDouble()
        val m = (mean / n).coerceIn(0.05, 0.95)
        val gamma = (ln(0.45) / ln(m)).coerceIn(0.65, 1.2).toFloat()
        val lut = IntArray(256) { (lvl(it).pow(gamma) * 255f).roundToInt() }

        // 3) Apply LUT + saturation boost
        val sat = 1.15f
        for (i in 0 until n) {
            val p = px[i]
            val r = lut[(p shr 16) and 255]; val g = lut[(p shr 8) and 255]; val b = lut[p and 255]
            val y = (r * 77 + g * 150 + b * 29) shr 8
            fun s(c: Int) = (y + (c - y) * sat).roundToInt().coerceIn(0, 255)
            px[i] = (p and 0xFF000000.toInt()) or (s(r) shl 16) or (s(g) shl 8) or s(b)
        }

        // 4) Sharpen (3x3 unsharp-style kernel)
        val a = 0.35f
        val o = px.copyOf()
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            var res = o[i] and 0xFF000000.toInt()
            for (sh in intArrayOf(16, 8, 0)) {
                val c = (o[i] shr sh) and 255
                val nb = ((o[i - 1] shr sh) and 255) + ((o[i + 1] shr sh) and 255) +
                        ((o[i - w] shr sh) and 255) + ((o[i + w] shr sh) and 255)
                val v = (c * (1 + 4 * a) - a * nb).roundToInt().coerceIn(0, 255)
                res = res or (v shl sh)
            }
            px[i] = res
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
