package com.example.aicam

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.camera.video.AudioConfig
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("MissingPermission")
@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val exec = remember { ContextCompat.getMainExecutor(ctx) }
    val controller = remember { LifecycleCameraController(ctx).apply { setEnabledUseCases(CameraController.IMAGE_CAPTURE) } }

    var video by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var enhance by remember { mutableStateOf(true) }
    var grid by remember { mutableStateOf(false) }
    var timer by remember { mutableIntStateOf(0) }
    var flash by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var countdown by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var ev by remember { mutableFloatStateOf(0f) }

    DisposableEffect(owner) { controller.bindToLifecycle(owner); onDispose { controller.unbind() } }

    fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun shoot() {
        val name = "IMG_${stamp()}"
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AICam")
        }
        val opts = ImageCapture.OutputFileOptions.Builder(ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        controller.imageCaptureFlashMode = flash
        controller.takePicture(opts, exec, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                val uri = r.savedUri; lastUri = uri
                if (enhance && uri != null) scope.launch {
                    busy = true
                    val u = withContext(Dispatchers.Default) { Enhancer.enhanceAndSave(ctx, uri, name) }
                    lastUri = u ?: uri; busy = false
                    msg = if (u != null) "Saved + AI enhanced" else "Saved (enhance failed)"
                } else msg = "Saved"
            }
            override fun onError(e: ImageCaptureException) { msg = "Error: ${e.message}" }
        })
    }

    fun onShutter() {
        if (video) {
            val rec = recording
            if (rec != null) { rec.stop(); recording = null; return }
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "VID_${stamp()}")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AICam")
            }
            val o = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setContentValues(cv).build()
            recording = controller.startRecording(o, AudioConfig.create(true), exec) { e ->
                if (e is VideoRecordEvent.Finalize) {
                    recording = null
                    msg = if (e.hasError()) "Video error" else "Video saved"
                    if (!e.hasError()) lastUri = e.outputResults.outputUri
                }
            }
        } else scope.launch {
            for (i in timer downTo 1) { countdown = i; delay(1000) }
            countdown = 0; shoot()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            PreviewView(c).apply { this.controller = controller; scaleType = PreviewView.ScaleType.FIT_CENTER }
        }) // pinch-to-zoom and tap-to-focus are built in

        if (grid) Canvas(Modifier.fillMaxSize()) {
            for (i in 1..2) {
                drawLine(Color.White.copy(0.5f), Offset(size.width * i / 3, 0f), Offset(size.width * i / 3, size.height))
                drawLine(Color.White.copy(0.5f), Offset(0f, size.height * i / 3), Offset(size.width, size.height * i / 3))
            }
        }

        // Top bar
        Row(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(when (flash) { ImageCapture.FLASH_MODE_AUTO -> "⚡ Auto"; ImageCapture.FLASH_MODE_ON -> "⚡ On"; else -> "⚡ Off" }) {
                flash = when (flash) { ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO; ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON; else -> ImageCapture.FLASH_MODE_OFF }
                controller.enableTorch(video && flash == ImageCapture.FLASH_MODE_ON)
            }
            Chip(if (timer == 0) "⏱ Off" else "⏱ ${timer}s") { timer = when (timer) { 0 -> 3; 3 -> 10; else -> 0 } }
            Chip(if (grid) "▦ Grid" else "▢ Grid") { grid = !grid }
            Chip(if (enhance) "✨ AI On" else "✨ AI Off") { enhance = !enhance }
        }

        if (countdown > 0) Text("$countdown", Modifier.align(Alignment.Center), color = Color.White, style = MaterialTheme.typography.displayLarge)
        if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))

        // Bottom controls
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (msg.isNotEmpty()) Text(msg, color = Color.White)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("EV", color = Color.White)
                Slider(ev, { v ->
                    ev = v
                    val r = controller.cameraInfo?.exposureState?.exposureCompensationRange
                    if (r != null) controller.cameraControl?.setExposureCompensationIndex(
                        (v * (if (v < 0) -r.lower else r.upper)).toInt())
                }, valueRange = -1f..1f, modifier = Modifier.width(240.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                Chip("Photo", !video) { if (recording == null) { video = false; controller.setEnabledUseCases(CameraController.IMAGE_CAPTURE) } }
                Chip("Video", video) { if (recording == null) { video = true; controller.setEnabledUseCases(CameraController.VIDEO_CAPTURE) } }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                Chip("Gallery") {
                    lastUri?.let { ctx.startActivity(Intent(Intent.ACTION_VIEW, it).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                }
                Box(Modifier.size(76.dp).border(4.dp, Color.White, CircleShape).padding(8.dp)
                    .background(if (recording != null) Color.Red else if (video) Color(0xFFFF5252) else Color.White, CircleShape)
                    .clickable { onShutter() })
                Chip("Flip") {
                    controller.cameraSelector = if (controller.cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA)
                        CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Text(text, color = if (selected) Color.Yellow else Color.White,
        modifier = Modifier.background(Color(0x66000000), CircleShape).clickable { onClick() }.padding(horizontal = 12.dp, vertical = 8.dp))
}
